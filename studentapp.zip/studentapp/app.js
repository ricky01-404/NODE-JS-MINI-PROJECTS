//app.js (Simple Express CRUD API)
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

let students = [
  { id: 1, name: "John", age: 20 },
  { id: 2, name: "Sara", age: 22 },
];

// GET all students
app.get("/students", (req, res) => {
  res.json(students);
});

// GET student by ID
app.get("/students/:id", (req, res) => {
  const stu = students.find(s => s.id == req.params.id);
  if (!stu) return res.status(404).json({ message: "Not Found" });
  res.json(stu);
});

// POST create student
app.post("/students", (req, res) => {
  const newStudent = {
    id: students.length + 1,
    name: req.body.name,
    age: req.body.age
  };
  students.push(newStudent);
  res.json(newStudent);
});

// PUT update student
app.put("/students/:id", (req, res) => {
  const stu = students.find(s => s.id == req.params.id);
  if (!stu) return res.status(404).json({ message: "Not Found" });
  stu.name = req.body.name;
  stu.age = req.body.age;
  res.json(stu);
});

// DELETE student
app.delete("/students/:id", (req, res) => {
  students = students.filter(s => s.id != req.params.id);
  res.json({ message: "Deleted successfully" });
});

app.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
});